Allow users to NIP-05 verify themselves at a domain you control

Lets users to sell NIP-05 verification to other nostr users on a domain they control.

Make sure to check the guide after installing for details on how to set up.
